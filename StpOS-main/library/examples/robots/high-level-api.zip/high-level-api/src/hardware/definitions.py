from libstp.datatypes import Axis, Direction
from libstp.motor import Motor
from libstp.servo import Servo


class Definitions:
    left_front_motor = Motor(0)
    right_front_motor = Motor(1)
    # left_front_sensor = AdvancedLightSensor(0)
    # right_front_sensor = AdvancedLightSensor(1)
    servo = Servo(0)
    axis: Axis = Axis.X
    direction: Direction = Direction.Normal

    def __init__(self):
        pass