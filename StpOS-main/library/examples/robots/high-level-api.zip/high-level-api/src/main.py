import asyncio

from libstp_helpers.api.device.two_wheeled import TwoWheeledDevice
from libstp_helpers.api.robot import Robot

from src.hardware.definitions import Definitions
from src.missions.example_mission import ExampleMission

robot = Robot(TwoWheeledDevice, Definitions)

robot.use_missions(
    ExampleMission()
)


@robot.on_shutdown
async def shutdown(device, defs):
    print("Disabling servos...")
    await asyncio.sleep(1)  # simulate wait


@robot.on_startup
async def setup(device, defs):
    device.set_heading_pid(-5.0, -0.1, 0.0)


robot.set_auto_shutdown(seconds=119)
robot.start()
