from libstp_helpers.api.missions import Mission
from libstp_helpers.api.steps import *
from libstp_helpers.api.steps.sequential import Sequential


class ExampleMission(Mission):
    def sequence(self) -> Sequential:
        return seq([
            drive_forward(10, 1),
            drive_backward(1, 1),
            turn_cw(90, 1),
            turn_ccw(90, 1),
            drive_forward(1, 1),
            wait(1),
            drive_forward(1, 1),
            drive_backward(1, 1),
        ])
